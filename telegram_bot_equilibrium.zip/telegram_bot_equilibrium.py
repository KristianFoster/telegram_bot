import logging
import os
import tempfile
from telegram import Update, InputFile
from telegram.ext import (
    Application, CommandHandler, MessageHandler, filters, ContextTypes,
    ConversationHandler
)

# Укажите значения токена и chat_id здесь для тестирования
TOKEN = os.getenv("TELEGRAM_BOT_TOKEN") or "7843179697:AAH8grRQb_wlgieDFENF-MFPk_MGwIp7x4k"
YOUR_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID") or "-1002482210031"

# Константы для ConversationHandler
ASK_TITLE, ASK_FILE = range(2)

# Проверка токена и chat_id
if not TOKEN or not YOUR_CHAT_ID:
    print("Ошибка: Необходимо указать TELEGRAM_BOT_TOKEN и TELEGRAM_CHAT_ID в переменных окружения.")
    exit(1)

# Настройка логирования
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO
)


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Стартовый обработчик"""
    user_name = update.message.from_user.first_name or "Гость"
    context.user_data["nickname"] = user_name
    await update.message.reply_text(f"Привет, {user_name}! Введите название композиции.")
    return ASK_TITLE


async def ask_file(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Обработчик запроса файла"""
    context.user_data["title"] = update.message.text
    await update.message.reply_text(
        f"Спасибо! Теперь отправьте MP3 файл для композиции \"{context.user_data['title']}\"."
    )
    return ASK_FILE


async def handle_audio(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Обработчик аудиосообщений"""
    audio_file = update.message.audio
    if audio_file:
        try:
            await update.message.reply_text("Подождите пару секунд. Файл отправляется...")

            with tempfile.NamedTemporaryFile(suffix=".mp3", delete=False) as temp_file:
                file_id = audio_file.file_id
                new_file = await context.bot.get_file(file_id)
                await new_file.download_to_drive(temp_file.name)
                file_path = temp_file.name

            with open(file_path, "rb") as f:
                input_file = InputFile(f)
                await context.bot.send_audio(
                    chat_id=YOUR_CHAT_ID,
                    audio=input_file,
                    caption=f"Композиция: {context.user_data['title']}\nОтправитель: {context.user_data['nickname']}"
                )

            await update.message.reply_text("Файл успешно отправлен!")
            os.remove(file_path)

            # Сообщение с инструкцией
            await update.message.reply_text(
                "Если вы хотите добавить ещё один трек, выберите в меню кнопку \"Старт\"."
            )

        except Exception as e:
            await update.message.reply_text(f"Ошибка: {e}")
            logging.exception(f"Ошибка: {e}")
    return ConversationHandler.END


async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Обработчик отмены"""
    await update.message.reply_text("Действие отменено.")
    return ConversationHandler.END


def main() -> None:
    """Основная функция запуска бота"""
    # Создание приложения с увеличенным таймаутом
    application = Application.builder().token(TOKEN).build()

    # Увеличение таймаута запросов
    application.bot.request._client.timeout = 60  # Таймаут в секундах

    # Обработчик с состояниями
    conv_handler = ConversationHandler(
        entry_points=[CommandHandler("start", start)],
        states={
            ASK_TITLE: [MessageHandler(filters.TEXT & ~filters.COMMAND, ask_file)],
            ASK_FILE: [MessageHandler(filters.AUDIO & ~filters.COMMAND, handle_audio)],
        },
        fallbacks=[CommandHandler("cancel", cancel)],
    )

    # Регистрация обработчиков
    application.add_handler(conv_handler)

    # Запуск бота
    application.run_polling()


if __name__ == "__main__":
    main()



